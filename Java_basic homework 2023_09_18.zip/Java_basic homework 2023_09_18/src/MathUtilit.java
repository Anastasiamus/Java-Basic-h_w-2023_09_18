public class MathUtilit {
    private MathUtilit() {
    }

    public static double addAll(double... numbers) {
        double sum = 0;
        for (double num : numbers) {
            sum += num;
        }
        return sum;
    }

    public static double minusAll(double base, double ... numbers) {
        for (double num : numbers) {
            base -= num;
        }
        return base;
    }


    public static double multAll(double... numbers) {
        double result = 1;
        for (double num : numbers) {
            result *= num;
        }
        return result;
    }


    public static double powAll(double base, double... powers) {
        double result = base;
        for (double power : powers) {
            result = Math.pow(result, power);
        }
        return result;
    }
}

